import SwiftUI

struct ContentView: View {
    @State private var currentTime = Date()
    
    let timer = Timer.publish(every: 1, on: .main, in: .common).autoconnect()
    
    var body: some View {
        Text("\(formattedTime(date: currentTime))")
            .font(.largeTitle)
            .onReceive(timer) { time in
                self.currentTime = time
            }
    }
    
    func formattedTime(date: Date) -> String {
        let formatter = DateFormatter()
        formatter.timeStyle = .medium
        return formatter.string(from: date)
    }
}
