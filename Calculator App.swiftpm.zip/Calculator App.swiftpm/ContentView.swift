import SwiftUI

struct ContentView: View {
    // Input variables
    @State private var number1: Double = 0
    @State private var number2: Double = 0
    
    // Variables to store results
    @State private var additionResult: Double = 0
    @State private var subtractionResult: Double = 0
    @State private var multiplicationResult: Double = 0
    @State private var divisionResult: Double = 0
    @State private var percentageResult: Double = 0
    
    var body: some View {
        VStack {
            // Top section: Input variables
            HStack {
                TextField("Enter number 1", value: $number1, formatter: NumberFormatter())
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .padding()
                TextField("Enter number 2", value: $number2, formatter: NumberFormatter())
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .padding()
            }
            
            // Middle section: Operations
            HStack {
                Button("Add") {
                    additionResult = number1 + number2
                }
                Button("Subtract") {
                    subtractionResult = number1 - number2
                }
                Button("Multiply") {
                    multiplicationResult = number1 * number2
                }
                Button("Divide") {
                    if number2 != 0 {
                        divisionResult = number1 / number2
                    }
                }
                Button("Percentage") {
                    percentageResult = (number1 / 100) * number2
                }
            }
            
            // Bottom section: Results
            VStack {
                Text("Addition Result: \(additionResult)")
                Text("Subtraction Result: \(subtractionResult)")
                Text("Multiplication Result: \(multiplicationResult)")
                Text("Division Result: \(divisionResult)")
                Text("Percentage Result: \(percentageResult)")
            }
            .padding()
        }
        .padding()
    }
}
