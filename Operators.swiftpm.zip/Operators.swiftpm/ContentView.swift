import SwiftUI

struct ContentView: View {
    var body: some View {
        MyView()
    }
}

struct MyView: View {
    var body: some View {
        VStack {
            Text("Welcome to My App!")
                .font(.title)
                .padding()
            Text(demonstrateOperators())
                .multilineTextAlignment(.center)
                .padding()
        }
    }
}

func demonstrateOperators() -> String {
    var output = ""
    
    let a = 5
    let b = 3
    let c = a + b
    output += "The result of \(a) + \(b) is \(c)\n"
    
    let x = 10
    let y = 5
    output += "Is \(x) equal to \(y)? \(x == y)\n"
    output += "Is \(x) not equal to \(y)? \(x != y)\n"
    output += "Is \(x) greater than \(y)? \(x > y)\n"
    output += "Is \(x) less than \(y)? \(x < y)\n"
    output += "Is \(x) greater than or equal to \(y)? \(x >= y)\n"
    output += "Is \(x) less than or equal to \(y)? \(x <= y)\n"
    
    let additionResult = a + b
    let subtractionResult = a - b
    let multiplicationResult = a * b
    let divisionResult = a / b
    let concatenationResult = "Hello" + " " + "world"
    output += "Addition: \(additionResult)\n"
    output += "Subtraction: \(subtractionResult)\n"
    output += "Multiplication: \(multiplicationResult)\n"
    output += "Division: \(divisionResult)\n"
    output += "Concatenation: \(concatenationResult)\n"
    
    let remainderResult1 = 10 % 3
    let remainderResult2 = 10 % 6
    output += "Remainder of 10 divided by 3 is \(remainderResult1)\n"
    output += "Remainder of 10 divided by 6 is \(remainderResult2)\n"
    
    var x1 = 6
    x1 += 2
    x1 -= 2
    x1 *= 2
    x1 /= 2
    output += "x1 after compound assignments: \(x1)\n"
    
    for i in 1...3 {
        output += "Number: \(i)\n"
    }
    
    for i in 1..<3 {
        output += "Number: \(i)\n"
    }
    
    let z = (y > x ? "Y is greater" : "X is greater")
    output += "\(z)\n"
    
    let isTrue = true
    let isFalse = !isTrue
    output += "Logical NOT of true is \(isFalse)\n"
    
    let p = true
    let q = false
    let r = p && q
    output += "Logical AND of true and false is \(r)\n"
    
    let m = true
    let n = false
    let o = m || n
    output += "Logical OR of true and false is \(o)\n"
    
    return output
}
